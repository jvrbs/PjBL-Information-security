package com.pucpr.repository;
import com.pucpr.model.Usuario;
import java.util.Optional;

public class UsuarioRepository {
    public Optional<Usuario> findByEmail(String email) {
        // TODO: O ALUNO DEVE IMPLEMENTAR
        // 1. Ler a lista de usuários do arquivo 'usuarios.json' usando Jackson.
        // 2. Filtrar a lista pelo e-mail ignorando maiúsculas/minúsculas.
        // 3. Retornar um Optional.
        return Optional.empty();
    }
}
