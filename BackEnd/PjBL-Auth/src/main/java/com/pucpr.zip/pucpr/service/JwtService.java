package com.pucpr.service;
import com.pucpr.model.Usuario;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.util.Date;

public class JwtService {

    public String generateToken(Usuario user) {
        // Exemplo de implementação que eles podem seguir ou completar
        String secret = System.getenv("JWT_SECRET"); // Ensinar boas práticas!
        return Jwts.builder()
                .subject(user.getEmail())
                .claim("role", user.getRole())
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + 900000)) // 15 min
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();
    }

    public boolean validateToken(String token) {
        // TODO: O ALUNO DEVE IMPLEMENTAR
        // Validar se o token é autêntico e se não expirou.
        return false;
    }

}
