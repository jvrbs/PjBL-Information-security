package com.pucpr.handlers;
import com.pucpr.repository.UsuarioRepository;
import com.pucpr.service.JwtService;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;

public class AuthHandler {

    public AuthHandler(UsuarioRepository repository, JwtService jwtService) {
    }

    public void handleLogin(HttpExchange exchange) throws IOException {
        if (!"POST".equals(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        // TODO: O ALUNO DEVE IMPLEMENTAR
        // 1. Ler o InputStream do 'exchange'.
        // 2. Validar se a senha enviada bate com o hash no JSON usando BCrypt.checkpw().
        // 3. Se OK, gerar o token e enviar no corpo da resposta.
        // 4. Se ERRO, enviar 401 Unauthorized com mensagem genérica.
    }

    public void handleRegister(HttpExchange httpExchange) {
    }
}
